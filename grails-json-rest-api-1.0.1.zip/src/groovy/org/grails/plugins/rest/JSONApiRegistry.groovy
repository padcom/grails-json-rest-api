package org.grails.plugins.rest

class JSONApiRegistry {
    static registry = [:]
}
